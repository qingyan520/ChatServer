enum MSG
{
  LOGIN_MSG=1 ,//登录标记
  LOGIN_MSG_ACK,//登录回复
  REG_MSG,//注册标记
  REG_MSG_ACK,//注册回复
  ONE_CHAT_MSG,//点对点聊天
  ADD_FRIEND_MSG,//添加好友信息
  CREATE_GROUP_MSG,//创建群组
  ADD_GROUP_MSG,//加入群组
  GROUP_CHAT_MSG//群聊天
};
